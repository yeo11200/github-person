// 메인 컴포넌트만 export하여 내부 구현을 캡슐화합니다.
export { default } from './ui/Modal';
// 외부에서 Modal의 props 타입을 사용할 수 있도록 export합니다.
export type { ModalProps } from './ui/Modal';
