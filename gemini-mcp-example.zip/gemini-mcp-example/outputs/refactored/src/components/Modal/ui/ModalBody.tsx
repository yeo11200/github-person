import React, { memo } from 'react';
import styles from '../Modal.module.scss';
interface ModalBodyProps {
  message: string;
}
/**
 * 모달의 본문 영역을 렌더링하는 컴포넌트입니다.
 * 메시지를 표시합니다.
 * props가 변경되지 않으면 리렌더링되지 않도록 React.memo로 최적화합니다.
 */
const ModalBody: React.FC<ModalBodyProps> = ({ message }) => {
  return (
    <div className={styles.modalBody}>
      <p className={styles.modalMessage}>{message}</p>
    </div>
  );
};
export default memo(ModalBody);
