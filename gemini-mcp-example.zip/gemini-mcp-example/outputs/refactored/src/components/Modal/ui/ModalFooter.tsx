import React, { memo } from 'react';
import styles from '../Modal.module.scss';
interface ModalFooterProps {
  type: 'alert' | 'confirm';
  onClose: () => void;
  onConfirm: () => void;
  confirmText: string;
  cancelText: string;
}
/**
 * 모달의 푸터 영역을 렌더링하는 컴포넌트입니다.
 * 확인 및 취소 버튼을 표시하고 관련 액션을 처리합니다.
 * props가 변경되지 않으면 리렌더링되지 않도록 React.memo로 최적화합니다.
 */
const ModalFooter: React.FC<ModalFooterProps> = ({
  type,
  onClose,
  onConfirm,
  confirmText,
  cancelText,
}) => {
  return (
    <div className={styles.modalFooter}>
      {type === 'confirm' && (
        <button
          className={`${styles.modalBtn} ${styles.cancelBtn}`}
          onClick={onClose}
        >
          {cancelText}
        </button>
      )}
      <button
        className={`${styles.modalBtn} ${styles.confirmBtn}`}
        onClick={onConfirm}
      >
        {confirmText}
      </button>
    </div>
  );
};
export default memo(ModalFooter);
