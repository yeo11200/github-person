import React, { memo } from 'react';
import styles from '../Modal.module.scss';
interface ModalBackdropProps {
  onClick: (e: React.MouseEvent) => void;
  children: React.ReactNode;
}
/**
 * 모달의 오버레이 배경을 렌더링하는 컴포넌트입니다.
 * 클릭 시 모달을 닫는 기능을 담당합니다.
 * props가 변경되지 않으면 리렌더링되지 않도록 React.memo로 최적화합니다.
 */
const ModalBackdrop: React.FC<ModalBackdropProps> = ({ onClick, children }) => {
  return (
    <div className={styles.modalOverlay} onClick={onClick}>
      {children}
    </div>
  );
};
export default memo(ModalBackdrop);
