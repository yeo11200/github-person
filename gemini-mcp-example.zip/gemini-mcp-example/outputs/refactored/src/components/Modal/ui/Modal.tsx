import React, { memo } from 'react';
import { useModal } from '../model/useModal';
import ModalBackdrop from './ModalBackdrop';
import ModalHeader from './ModalHeader';
import ModalBody from './ModalBody';
import ModalFooter from './ModalFooter';
import styles from '../Modal.module.scss';
export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  message: string;
  type: 'alert' | 'confirm';
  onConfirm?: () => void;
  confirmText?: string;
  cancelText?: string;
}
/**
 * 메인 Modal UI 컴포넌트입니다.
 * 하위 UI 컴포넌트(Backdrop, Header, Body, Footer)들을 조합하여 완전한 모달을 렌더링합니다.
 * 비즈니스 로직은 useModal 훅에 위임합니다.
 * props가 변경되지 않으면 리렌더링되지 않도록 React.memo로 최적화합니다.
 */
const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  message,
  type,
  onConfirm,
  confirmText = '확인',
  cancelText = '취소',
}) => {
  const { handleConfirm, handleBackdropClick } = useModal({
    onClose,
    onConfirm,
  });
  if (!isOpen) return null;
  return (
    <ModalBackdrop onClick={handleBackdropClick}>
      <div className={styles.modalContent}>
        <ModalHeader title={title} />
        <ModalBody message={message} />
        <ModalFooter
          type={type}
          onClose={onClose}
          onConfirm={handleConfirm}
          confirmText={confirmText}
          cancelText={cancelText}
        />
      </div>
    </ModalBackdrop>
  );
};
export default memo(Modal);
