import React, { memo } from 'react';
import styles from '../Modal.module.scss';
interface ModalHeaderProps {
  title: string;
}
/**
 * 모달의 헤더 영역을 렌더링하는 컴포넌트입니다.
 * 제목을 표시합니다.
 * props가 변경되지 않으면 리렌더링되지 않도록 React.memo로 최적화합니다.
 */
const ModalHeader: React.FC<ModalHeaderProps> = ({ title }) => {
  return (
    <div className={styles.modalHeader}>
      <h3 className={styles.modalTitle}>{title}</h3>
    </div>
  );
};
export default memo(ModalHeader);
