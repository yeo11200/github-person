import { useCallback } from 'react';
interface UseModalParams {
  onClose: () => void;
  onConfirm?: () => void;
}
/**
 * Modal 컴포넌트의 비즈니스 로직을 담당하는 커스텀 훅입니다.
 * 확인 및 닫기 핸들러를 생성하고 관리합니다.
 */
export const useModal = ({ onClose, onConfirm }: UseModalParams) => {
  /**
   * 확인 버튼 클릭 시 실행되는 핸들러입니다.
   * onConfirm 콜백이 있으면 실행하고, 항상 모달을 닫습니다.
   * 자식 컴포넌트(ModalFooter)에 props로 전달되므로 useCallback으로 메모이제이션합니다.
   */
  const handleConfirm = useCallback(() => {
    onConfirm?.();
    onClose();
  }, [onConfirm, onClose]);
  /**
   * 모달의 배경(Backdrop) 클릭 시 실행되는 핸들러입니다.
   * 이벤트가 발생한 타겟이 현재 타겟(배경)과 같을 때만 모달을 닫습니다.
   * 자식 컴포넌트(ModalBackdrop)에 props로 전달되므로 useCallback으로 메모이제이션합니다.
   */
  const handleBackdropClick = useCallback(
    (e: React.MouseEvent) => {
      if (e.target === e.currentTarget) {
        onClose();
      }
    },
    [onClose],
  );
  return {
    handleConfirm,
    handleBackdropClick,
  };
};
