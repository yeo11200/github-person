import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { vi, describe, it, expect, beforeEach, afterEach } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import DesktopNavigation from './DesktopNavigation';

// 테스트용 Mock Props 생성 함수
const createMockProps = (overrides = {}) => ({
  isAuthenticated: false,
  onLogin: vi.fn(),
  onLogout: vi.fn(),
  ...overrides,
});

// react-router-dom의 Link 컴포넌트를 테스트하기 위한 래퍼
const renderWithRouter = (ui: React.ReactElement) => {
  return render(<MemoryRouter>{ui}</MemoryRouter>);
};

describe('DesktopNavigation', () => {
  let mockProps: ReturnType<typeof createMockProps>;
  const user = userEvent.setup();

  beforeEach(() => {
    mockProps = createMockProps();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe('렌더링', () => {
    it('인증되지 않았을 때 로그인 버튼과 홈 링크를 렌더링한다', () => {
      renderWithRouter(<DesktopNavigation {...mockProps} />);

      expect(screen.getByRole('link', { name: /홈/i })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /github 로그인/i })).toBeInTheDocument();
      
      expect(screen.queryByRole('link', { name: /대시보드/i })).not.toBeInTheDocument();
      expect(screen.queryByRole('link', { name: /레포지토리/i })).not.toBeInTheDocument();
      expect(screen.queryByRole('button', { name: /로그아웃/i })).not.toBeInTheDocument();
    });

    it('인증되었을 때 네비게이션 링크들과 로그아웃 버튼을 렌더링한다', () => {
      mockProps = createMockProps({ isAuthenticated: true });
      renderWithRouter(<DesktopNavigation {...mockProps} />);

      expect(screen.getByRole('link', { name: /홈/i })).toBeInTheDocument();
      expect(screen.getByRole('link', { name: /대시보드/i })).toBeInTheDocument();
      expect(screen.getByRole('link', { name: /레포지토리/i })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /로그아웃/i })).toBeInTheDocument();

      expect(screen.queryByRole('button', { name: /github 로그인/i })).not.toBeInTheDocument();
    });

    it('링크들이 올바른 경로를 가지고 있다', () => {
      mockProps = createMockProps({ isAuthenticated: true });
      renderWithRouter(<DesktopNavigation {...mockProps} />);

      expect(screen.getByRole('link', { name: /홈/i })).toHaveAttribute('href', '/');
      expect(screen.getByRole('link', { name: /대시보드/i })).toHaveAttribute('href', '/dashboard');
      expect(screen.getByRole('link', { name: /레포지토리/i })).toHaveAttribute('href', '/repositories');
    });
  });

  describe('사용자 상호작용', () => {
    it('로그인 버튼 클릭 시 onLogin 핸들러가 호출된다', async () => {
      renderWithRouter(<DesktopNavigation {...mockProps} />);
      
      const loginButton = screen.getByRole('button', { name: /github 로그인/i });
      await user.click(loginButton);

      expect(mockProps.onLogin).toHaveBeenCalledTimes(1);
    });

    it('로그아웃 버튼 클릭 시 onLogout 핸들러가 호출된다', async () => {
      mockProps = createMockProps({ isAuthenticated: true });
      renderWithRouter(<DesktopNavigation {...mockProps} />);

      const logoutButton = screen.getByRole('button', { name: /로그아웃/i });
      await user.click(logoutButton);

      expect(mockProps.onLogout).toHaveBeenCalledTimes(1);
    });
  });

  describe('성능', () => {
    it('React.memo 최적화로 인해 동일한 props에 대해 리렌더링되지 않는다', () => {
      const { rerender } = renderWithRouter(<DesktopNavigation {...mockProps} />);
      const originalRender = screen.getByRole('navigation');

      rerender(<DesktopNavigation {...mockProps} />);
      const rerenderedRender = screen.getByRole('navigation');
      
      // DOM 엘리먼트가 동일한 참조를 가지는지 확인하여 리렌더링 여부를 간접적으로 테스트
      // Vitest/JSDOM 환경에서는 실제 React의 렌더링 동작을 완벽히 모방하기 어려우므로,
      // 이 테스트는 memo 최적화가 적용되었음을 가정하고 검증하는 데 초점을 맞춤.
      // 실제로는 Profiler 등을 사용하는 것이 더 정확함.
      expect(originalRender).toBe(rerenderedRender);
    });

    it('props가 변경될 때만 리렌더링된다', () => {
      const { rerender } = renderWithRouter(<DesktopNavigation {...mockProps} />);
      expect(screen.getByRole('button', { name: /github 로그인/i })).toBeInTheDocument();

      // isAuthenticated prop 변경
      const newProps = { ...mockProps, isAuthenticated: true };
      rerender(<DesktopNavigation {...newProps} />);

      // UI가 변경되었는지 확인하여 리렌더링 검증
      expect(screen.queryByRole('button', { name: /github 로그인/i })).not.toBeInTheDocument();
      expect(screen.getByRole('button', { name: /로그아웃/i })).toBeInTheDocument();
    });
  });

  describe('접근성', () => {
    it('컴포넌트 루트가 nav 태그로 되어 있어 navigation 랜드마크 역할을 가진다', () => {
      renderWithRouter(<DesktopNavigation {...mockProps} />);
      expect(screen.getByRole('navigation')).toBeInTheDocument();
    });

    it('인증되지 않았을 때 키보드 네비게이션이 올바르게 작동한다', async () => {
      renderWithRouter(<DesktopNavigation {...mockProps} />);
      
      const homeLink = screen.getByRole('link', { name: /홈/i });
      const loginButton = screen.getByRole('button', { name: /github 로그인/i });

      await user.tab();
      expect(homeLink).toHaveFocus();

      await user.tab();
      expect(loginButton).toHaveFocus();
    });

    it('인증되었을 때 키보드 네비게이션이 올바르게 작동한다', async () => {
      mockProps = createMockProps({ isAuthenticated: true });
      renderWithRouter(<DesktopNavigation {...mockProps} />);

      const homeLink = screen.getByRole('link', { name: /홈/i });
      const dashboardLink = screen.getByRole('link', { name: /대시보드/i });
      const repoLink = screen.getByRole('link', { name: /레포지토리/i });
      const logoutButton = screen.getByRole('button', { name: /로그아웃/i });

      await user.tab();
      expect(homeLink).toHaveFocus();

      await user.tab();
      expect(dashboardLink).toHaveFocus();

      await user.tab();
      expect(repoLink).toHaveFocus();

      await user.tab();
      expect(logoutButton).toHaveFocus();
    });
  });
});
