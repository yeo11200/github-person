import React from 'react';
import { render, screen } from '@testing-library/react';
import { vi, describe, it, expect } from 'vitest';
import UserInfo from '../ui/UserInfo'; // 경로가 원본 파일 위치에 따라 조정되었습니다.
import type { User } from '@/types/apis';

// Mock 데이터 팩토리
const createMockUser = (overrides: Partial<User> = {}): User => ({
  login: 'testuser',
  id: 1,
  node_id: 'MDQ6VXNlcjE=',
  avatar_url: 'https://avatars.githubusercontent.com/u/1?v=4',
  gravatar_id: '',
  url: 'https://api.github.com/users/testuser',
  html_url: 'https://github.com/testuser',
  followers_url: 'https://api.github.com/users/testuser/followers',
  following_url: 'https://api.github.com/users/testuser/following{/other_user}',
  gists_url: 'https://api.github.com/users/testuser/gists{/gist_id}',
  starred_url: 'https://api.github.com/users/testuser/starred{/owner}{/repo}',
  subscriptions_url: 'https://api.github.com/users/testuser/subscriptions',
  organizations_url: 'https://api.github.com/users/testuser/orgs',
  repos_url: 'https://api.github.com/users/testuser/repos',
  events_url: 'https://api.github.com/users/testuser/events{/privacy}',
  received_events_url: 'https://api.github.com/users/testuser/received_events',
  type: 'User',
  site_admin: false,
  name: 'Test User',
  company: 'Test Inc',
  blog: 'https://test.blog',
  location: 'Test City',
  email: 'test@example.com',
  hireable: true,
  bio: 'A test user bio.',
  twitter_username: 'testuser',
  public_repos: 10,
  public_gists: 5,
  followers: 100,
  following: 10,
  created_at: '2008-01-14T04:33:35Z',
  updated_at: '2023-01-14T04:33:35Z',
  ...overrides,
});

describe('UserInfo Component', () => {
  describe('렌더링 테스트', () => {
    it('기본 props(사용자 정보)로 정상 렌더링된다', () => {
      const mockUser = createMockUser();
      render(<UserInfo user={mockUser} />);

      // 사용자 이름이 표시되는지 확인
      expect(screen.getByText(mockUser.name!)).toBeInTheDocument();

      // 사용자 아바타가 표시되고, alt 속성과 src 속성이 올바른지 확인
      const avatar = screen.getByRole('img', { name: mockUser.name });
      expect(avatar).toBeInTheDocument();
      expect(avatar).toHaveAttribute('src', mockUser.avatar_url);
    });

    it('아바타 URL(avatar_url)이 null일 때 기본 아바타 이미지를 표시한다', () => {
      const mockUser = createMockUser({ avatar_url: null });
      render(<UserInfo user={mockUser} />);

      const avatar = screen.getByRole('img', { name: mockUser.name });
      expect(avatar).toBeInTheDocument();
      expect(avatar).toHaveAttribute('src', '/default-avatar.png');
    });

    it('아바타 URL(avatar_url)이 undefined일 때 기본 아바타 이미지를 표시한다', () => {
      const mockUser = createMockUser({ avatar_url: undefined });
      render(<UserInfo user={mockUser} />);

      const avatar = screen.getByRole('img', { name: mockUser.name });
      expect(avatar).toBeInTheDocument();
      expect(avatar).toHaveAttribute('src', '/default-avatar.png');
    });

    it('사용자 이름(name)이 null일 때도 에러 없이 렌더링된다', () => {
      const mockUser = createMockUser({ name: null });
      render(<UserInfo user={mockUser} />);

      // 이름이 없으므로, 텍스트로 찾을 수 없어야 함
      expect(screen.queryByText(/.+/)).not.toBeInTheDocument();

      // alt 속성은 빈 문자열로 설정됨
      const avatar = screen.getByRole('img');
      expect(avatar).toBeInTheDocument();
      expect(avatar).toHaveAttribute('alt', '');
    });
  });

  describe('성능 테스트', () => {
    it('React.memo로 최적화되어 동일한 props에 대해 리렌더링되지 않는다', () => {
      const mockUser = createMockUser();
      const renderSpy = vi.fn();

      // 렌더링을 추적하는 래퍼 컴포넌트
      const TestComponent = ({ user }: { user: User }) => {
        renderSpy();
        return <UserInfo user={user} />;
      };

      const { rerender } = render(<TestComponent user={mockUser} />);
      expect(renderSpy).toHaveBeenCalledTimes(1);

      // 동일한 props 객체로 리렌더링
      rerender(<TestComponent user={mockUser} />);
      expect(renderSpy).toHaveBeenCalledTimes(1); // 리렌더링되지 않아야 함

      // 새로운 props 객체로 리렌더링 (내용은 동일)
      const newUserSameContent = { ...mockUser };
      rerender(<TestComponent user={newUserSameContent} />);
      expect(renderSpy).toHaveBeenCalledTimes(2); // 리렌더링되어야 함

      // 다른 내용을 가진 새로운 props 객체로 리렌더링
      const differentUser = createMockUser({ name: 'Another User' });
      rerender(<TestComponent user={differentUser} />);
      expect(renderSpy).toHaveBeenCalledTimes(3); // 리렌더링되어야 함
    });
  });

  describe('접근성 테스트', () => {
    it('아바타 이미지에 사용자 이름을 alt 텍스트로 제공한다', () => {
      const mockUser = createMockUser({ name: 'Accessible User' });
      render(<UserInfo user={mockUser} />);

      const avatar = screen.getByRole('img');
      expect(avatar).toHaveAttribute('alt', 'Accessible User');
    });

    it('사용자 이름이 없는 경우 빈 alt 텍스트를 제공하여 스크린 리더가 무시하도록 한다', () => {
      const mockUser = createMockUser({ name: null });
      render(<UserInfo user={mockUser} />);

      const avatar = screen.getByRole('img');
      // 장식용 이미지의 경우 alt=""가 권장됨
      expect(avatar).toHaveAttribute('alt', '');
    });
  });

  // 이 컴포넌트는 사용자 상호작용(클릭, 입력 등)이 없으므로 관련 테스트는 생략합니다.
  // 또한, 자체적인 상태나 Context를 사용하지 않으므로 상태 관리 테스트도 생략합니다.
});
