// 메인 컴포넌트만 export하여 내부 구현을 캡슐화합니다.
export { default } from './ui/Header';
// 필요시 외부에서 사용할 타입도 export합니다.
export type { HeaderProps } from './ui/Header';
