# Gemini CLI + MCP 자동화 도구

이 프로젝트는 Gemini CLI와 MCP (Model Context Protocol) 도구를 활용하여 React 코드 분석 및 최적화를 자동화하는 도구입니다.

## 🚀 주요 기능

- **성능 분석**: React 컴포넌트의 불필요한 리렌더링 분석
- **코드 리팩토링**: 성능 최적화를 위한 코드 개선 제안
- **테스트 생성**: 컴포넌트에 대한 테스트 코드 자동 생성
- **폴더 구조 분석**: 프로젝트 구조 개선 제안

## 📋 사전 요구사항

1. **Gemini CLI 설치**

   ```bash
   npm install -g @google/generative-ai-cli
   ```

2. **MCP 서버 설정** (Claude Desktop 등)

## 🛠️ 사용법

### 1. 기본 실행

```bash
# 모든 작업 실행
./mcp-auto-run.sh all

# 개별 작업 실행
./mcp-auto-run.sh performance  # 성능 분석
./mcp-auto-run.sh refactor     # 리팩토링
./mcp-auto-run.sh test         # 테스트 생성
./mcp-auto-run.sh structure    # 구조 분석
```

### 2. 커스텀 파일 분석

```bash
# 특정 컴포넌트 분석
./mcp-auto-run.sh performance src/components/MyComponent.tsx

# 여러 파일 동시 분석
./mcp-auto-run.sh refactor src/components/*.tsx
```

## 📁 프로젝트 구조

```
gemini-mcp-example/
├── config/
│   └── mcp.config.json          # MCP 설정
├── prompts/
│   ├── performance.yaml         # 성능 분석 프롬프트
│   ├── refactor.yaml           # 리팩토링 프롬프트
│   ├── testgen.yaml            # 테스트 생성 프롬프트
│   └── folder_analysis.yaml    # 구조 분석 프롬프트
├── inputs/
│   ├── code/                   # 분석할 코드 파일
│   └── context/                # 컨텍스트 정보
├── outputs/
│   ├── performance/            # 성능 분석 결과
│   ├── refactored/            # 리팩토링된 코드
│   ├── tests/                 # 생성된 테스트
│   └── advice/                # 구조 개선 제안
└── mcp-auto-run.sh            # 메인 실행 스크립트
```

## 🎯 출력 예시

### 성능 분석 결과

- 불필요한 리렌더링 지점 식별
- `React.memo`, `useCallback`, `useMemo` 사용 제안
- 인라인 객체/함수로 인한 성능 이슈 분석

### 리팩토링 제안

- 최적화된 코드 구조
- 메모이제이션 적용
- 컴포넌트 분리 제안

## 🔧 설정 커스터마이징

`config/mcp.config.json`에서 다음을 수정할 수 있습니다:

- 모델 선택 (gemini-pro, gemini-pro-vision)
- Temperature 값
- 입력/출력 경로
- 프롬프트 템플릿

## 📝 라이센스

MIT License
